﻿using System;
using System.Runtime.InteropServices;
using System.Security.Principal;
using Microsoft.Win32;
using System.DirectoryServices;
using System.ServiceProcess;
using System.Diagnostics;


namespace EnablerOps
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine("                  by Timothians                     ");
            Console.WriteLine("----------------------------------------------------\n");

            if (args.Length < 2)
            {
                Console.WriteLine("[!] Error: Insufficient arguments provided.");
                Console.WriteLine("Usage: ");
                Console.WriteLine("  enabler.exe -localadmin <password>");
                return;
            }

            string mode = args[0];
            if (mode == "-localadmin")
            {
                string password = args[1];
                PerformLocalAdminActions(password);
            }
            else
            {
                Console.WriteLine("[!] Error: Invalid mode specified.");
            }
        }

        static void PerformLocalAdminActions(string password)
        {
            Console.WriteLine("[*] Running as: " + WindowsIdentity.GetCurrent().Name);
            Console.WriteLine("[*] Enabling Local Administrator...");

            if (EnableAdministratorAccount(password))
            {
                Console.WriteLine("[+] Local Administrator account enabled and password updated.");
            }
            else
            {
                Console.WriteLine("[!] Failed to modify the Local Administrator account.");
                return;
            }

            EnableRDP();
            AddUserToGroups("Administrator");

            Console.WriteLine("[+] Local Administrator setup completed successfully.");
        }

        static bool EnableAdministratorAccount(string password)
        {
            try
            {
                // Enable the account by setting UF_ACCOUNTDISABLE to false and updating the password
                USER_INFO_1008 accountControl = new USER_INFO_1008 { usri1008_flags = USER_FLAGS.UF_DONT_EXPIRE_PASS };
                int result = NetUserSetInfo(null, "Administrator", 1008, ref accountControl, out _);

                if (result != 0)
                {
                    Console.WriteLine($"[!] Failed to enable Administrator account. Error code: {result}");
                    return false;
                }

                // Update the password
                USER_INFO_1003 passwordInfo = new USER_INFO_1003 { usri1003_password = password };
                result = NetUserSetInfo(null, "Administrator", 1003, ref passwordInfo, out _);

                if (result != 0)
                {
                    Console.WriteLine($"[!] Failed to update password for Administrator account. Error code: {result}");
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[!] Exception occurred: {ex.Message}");
                return false;
            }
        }

        static void EnableRDP()
        {
            try
            {
                Console.WriteLine("[*] Enabling RDP...");

                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"System\CurrentControlSet\Control\Terminal Server", writable: true))
                {
                    key?.SetValue("fDenyTSConnections", 0, RegistryValueKind.DWord);
                }

                Console.WriteLine("[+] RDP Enabled.");
                EnableFirewallRuleForRDP();
                StartService("TermService", "[+] RDP Service started.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[!] Error enabling RDP: {ex.Message}");
            }
        }

        static void EnableFirewallRuleForRDP()
        {
            ExecuteCommand("netsh advfirewall firewall set rule group=\"remote desktop\" new enable=yes", "[+] Firewall rules updated for RDP.");
        }

        static void AddUserToGroups(string user)
        {
            Console.WriteLine($"[*] Adding '{user}' to Remote Desktop Users and Administrators...");

            AddUserToLocalGroup(user, "Remote Desktop Users");
            AddUserToLocalGroup(user, "Administrators");
        }

        static void AddUserToLocalGroup(string user, string groupName)
        {
            DirectoryEntry localMachine = new DirectoryEntry("WinNT://" + Environment.MachineName);
            DirectoryEntry group = localMachine.Children.Find(groupName, "Group");

            if (!IsUserInGroup(group, user))
            {
                group.Invoke("Add", new object[] { "WinNT://" + Environment.MachineName + "/" + user });
                Console.WriteLine($"[+] User '{user}' added to '{groupName}' group.");
            }
            else
            {
                Console.WriteLine($"[+] User '{user}' is already a member of '{groupName}' group.");
            }
        }

        static bool IsUserInGroup(DirectoryEntry group, string userName)
        {
            foreach (object member in (System.Collections.IEnumerable)group.Invoke("Members"))
            {
                DirectoryEntry memberEntry = new DirectoryEntry(member);
                if (memberEntry.Name.Equals(userName, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        static void StartService(string serviceName, string successMessage)
        {
            try
            {
                ServiceController service = new ServiceController(serviceName);
                if (service.Status == ServiceControllerStatus.Stopped)
                {
                    service.Start();
                    service.WaitForStatus(ServiceControllerStatus.Running);
                    Console.WriteLine(successMessage);
                }
                else
                {
                    Console.WriteLine($"[+] {serviceName} is already running.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[!] Error starting service '{serviceName}': {ex.Message}");
            }
        }

        static void ExecuteCommand(string command, string successMessage)
        {
            ProcessStartInfo processInfo = new ProcessStartInfo("cmd.exe", "/c " + command)
            {
                CreateNoWindow = true,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };

            using (Process process = Process.Start(processInfo))
            {
                string output = process.StandardOutput.ReadToEnd();
                string error = process.StandardError.ReadToEnd();

                process.WaitForExit();

                if (string.IsNullOrEmpty(error))
                {
                    Console.WriteLine(successMessage);
                }
                else
                {
                    Console.WriteLine($"[!] Error: {error.Trim()}");
                }
            }
        }

        [DllImport("Netapi32.dll", CharSet = CharSet.Unicode)]
        private static extern int NetUserSetInfo(string servername, string username, int level, ref USER_INFO_1008 buf, out int parm_err);

        [StructLayout(LayoutKind.Sequential)]
        private struct USER_INFO_1008
        {
            public USER_FLAGS usri1008_flags;
        }

        [DllImport("Netapi32.dll", CharSet = CharSet.Unicode)]
        private static extern int NetUserSetInfo(string servername, string username, int level, ref USER_INFO_1003 buf, out int parm_err);

        [StructLayout(LayoutKind.Sequential)]
        private struct USER_INFO_1003
        {
            [MarshalAs(UnmanagedType.LPWStr)]
            public string usri1003_password;
        }

        [Flags]
        private enum USER_FLAGS
        {
            UF_ACCOUNTDISABLE = 0x00000002,
            UF_DONT_EXPIRE_PASS = 0x00010000
        }
    }
}
